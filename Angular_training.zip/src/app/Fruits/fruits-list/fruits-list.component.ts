import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fruits-list',
  templateUrl: './fruits-list.component.html',
  styleUrls: ['./fruits-list.component.css']
})
export class FruitsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
