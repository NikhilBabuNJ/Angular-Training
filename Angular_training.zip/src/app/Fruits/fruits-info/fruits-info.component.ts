import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fruits-info',
  templateUrl: './fruits-info.component.html',
  styleUrls: ['./fruits-info.component.css']
})
export class FruitsInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
